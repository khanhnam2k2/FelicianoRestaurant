<?php

namespace App\Enums;

enum TableLocation: string
{
    case Front = 'front';
    case Inside = 'inside';
    case Outside = 'outside';
}
