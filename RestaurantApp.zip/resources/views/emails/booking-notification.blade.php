<p>Dear Admin, Hà Nam</p>

<p>A new table booking has been made by a customer:</p>

<ul>
    <li>Customer name: {{ $reservation->name }}</li>
    <li>Phone number: {{ $reservation->tel_number }}</li>
    <li>Email: {{ $reservation->email }}</li>
    <li>Date: {{ $reservation->res_date }}</li>
    <li>Number of guest: {{ $reservation->guest_number }}</li>
</ul>
<p>Please confirm your table reservation as soon as possible 😊😊😊</p>
<p>Thank you ❤️❤️❤️</p>