<h1>Booking Canceled</h1>


<p>Dear {{ $reservation->name }},</p>

<p>We regret to inform you that your order (ID #{{ $reservation->id }} Date: {{$reservation->res_date}}) has been cancelled due to unforeseen circumstances. We apologize for any inconvenience this may cause.</p>

<p>Please contact us if you have any questions or concerns.</p>
<ul>
    <li>Phone: 📞+0947837222</li>
    <li>Gmail: 📧 FelicianoRestaurant@gmail.com</li>
</ul>

<p>Best regards,<br>The Feliciano Restaurant</p>
