<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid  pt-4 px-4">
        <div class="row">
            <div class="col-lg-12">
                <div class="bg-secondary rounded h-100 p-4">
                    <h2>Show Post</h2>
                    <div class="row h-100 p-4 ">
                        <div class="col-md-6">
                                <div class="form-group">
                                    <strong>Title:</strong>
                                    <?php echo e($post->title); ?>

                                </div>
                        </div>
                        <div class="col-md-6">
                                <div class="form-group">
                                    <strong>Excerpt:</strong>
                                    <?php echo e($post->excerpt ?? 'No excerpt'); ?>

                                </div>
                        </div>
                        <div class="col-md-6">
                                <div class="form-group">
                                    <strong>Image:</strong>
                                    <img src="<?php echo e(Storage::url($post->image)); ?>" width="100%" alt="">
                                </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <strong>Body:</strong>
                                <?php echo e($post->body); ?>

                            </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <strong>Published:</strong>
                            <?php echo e($post->is_published == 1 ? "Post showed": "Post hidden"); ?>

                        </div>
                </div>
                    
                    </div>
                </div>
            </div>
        </div>
       
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\HA  NAM\Downloads\RestaurantApp\resources\views/admin/posts/show.blade.php ENDPATH**/ ?>