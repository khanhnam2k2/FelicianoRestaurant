<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-12">
                <div class="bg-secondary rounded h-100 p-4">
                    <a href="<?php echo e(route('admin.posts.create')); ?>" class="mb-4 btn btn-primary">New Post</a>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Title</th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Author</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($post->title); ?></td>
                                    <td>
                                        <img
                                            src="<?php echo e(Storage::url($post->image)); ?>"
                                            alt=""
                                            width="100%"
                                            height="200px"
                                            style="object-fit: cover"
                                        />
                                    </td>
                                    <td><?php echo e($post->is_published == 1 ? 'Posted' : 'Hidden'); ?></td>
                                    <td><?php echo e($post->user->name == Auth::user()->name ? "You" : $post->user->name); ?></td>
                                    <?php if($post->user->name == Auth::user()->name ): ?>
                                    <td>
                                        <div class="d-flex">
                                        <a href="<?php echo e(route('admin.posts.edit',$post->id)); ?>" class="btn btn-info me-2"><i class="fa-solid fa-pen-to-square"></i></a>
                                        <a href="<?php echo e(route('admin.posts.show',$post->id)); ?>" class="btn btn-success me-2"><i class="fa-solid fa-circle-info"></i></a>
                                        <form class=""
                                            method="POST"
                                            action="<?php echo e(route('admin.posts.destroy',$post->id)); ?>"
                                            onsubmit="return confirm('Are you sure?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger" type="submit"><i class="fa-solid fa-trash"></i></button>
                                        </form>
                                    </div>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                                
                                
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end"><?php echo e($posts->links()); ?></div>
                </div>
            </div>
        </div>

    </div>
  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
 <?php /**PATH D:\Đại học Vinh\Đồ ăn năm 3\RestaurantApp\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>