<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="home-slider owl-carousel js-fullheight">
      <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="slider-item js-fullheight" style="background-image: url(<?php echo e(Storage::url($slide->image)); ?>);">
          <div class="overlay"></div>
        <div class="container">
          <div class="row slider-text js-fullheight justify-content-center align-items-center" data-scrollax-parent="true">

            <div class="col-md-12 col-sm-12 text-center ftco-animate">
                <span class="subheading"><?php echo e($slide->subheading); ?></span>
              <h1 class="mb-4"><?php echo e($slide->heading); ?></h1>
            </div>

          </div>
        </div>
      </div>
          
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
       
      </section>
  
      

      
      <?php echo $__env->make('partials._about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
      
      <?php echo $__env->make('partials._services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  
      
      <section class="ftco-section">
          <div class="container">
              <div class="row no-gutters justify-content-center mb-5 pb-2">
            <div class="col-md-12 text-center heading-section ftco-animate">
                <span class="subheading">Specialties</span>
              <h2 class="mb-4">Our Menu</h2>
            </div>
          </div>
          <div class="row no-gutters d-flex align-items-stretch">
            <?php $__currentLoopData = $specials->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12 col-lg-6 d-flex align-self-stretch">
                <div class="menus d-sm-flex ftco-animate align-items-stretch mt-4 mr-4">
              <div class="menu-img img  " style="background-image: url(<?php echo e(Storage::url($menu->image)); ?>);"></div>
              <div class="text d-flex align-items-center">
                                <div>
                      <div class="d-flex">
                        <div class="one-half">
                          <h3><?php echo e($menu->name); ?></h3>
                        </div>
                        <div class="one-forth">
                          <span class="price">$<?php echo e($menu->price); ?></span>
                        </div>
                      </div>
                      <p class="mb-2 text-sm">
                        Categories: 
                        <?php $__currentLoopData = $menu->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class=""><?php echo e($category->name); ?>,</span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                    <div ><?php echo e($menu->description); ?></div>

                      <p><a href="#" class="btn btn-primary">See details</a></p>
                  </div>
              </div>
            </div>
            </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
          </div>
          </div>
      </section>
      
      
          <section class="ftco-section">
              <div class="container">
                  <div class="row justify-content-center mb-5 pb-2">
            <div class="col-md-12 text-center heading-section ftco-animate">
                <span class="subheading">Chef</span>
              <h2 class="mb-4">Our Master Chef</h2>
            </div>
          </div>	
                  <div class="row">
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.team-card','data' => ['team' => $team]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('team-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['team' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($team)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                  
                  </div>
              </div>
          </section>
  
          
          
          <section class="ftco-section bg-light">
              <div class="container">
                  <div class="row justify-content-center mb-5">
            <div class="col-md-7 text-center heading-section ftco-animate">
                <span class="subheading">Blog</span>
              <h2 class="mb-4">Recent Posts</h2>
            </div>
          </div>
                  <div class="row">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 ftco-animate">
                      <div class="blog-entry">
                        <a href="<?php echo e(route('post.show',$post->id)); ?>" class="block-20" style="background-image: url(<?php echo e(Storage::url($post->image)); ?>);">
                        </a>
                        <div class="text pt-3 pb-4 px-4">
                          <div class="meta">
                            <div><a href="#"><?php echo e($post->created_at->format('d-m-Y')); ?></a></div>
                            <div><a href="#"><?php echo e($post->user->name); ?></a></div>
                          </div>
                          <h3 class="heading"><a href="<?php echo e(route('post.show',$post->id)); ?>"><?php echo e($post->title); ?></a></h3>
                          <p class="clearfix">
                            <a href="<?php echo e(route('post.show',$post->id)); ?>" class="float-left read">Read more</a>
                          </p>
                        </div>
                      </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
          </div>
              </div>
          </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\Users\HA  NAM\Downloads\RestaurantApp\resources\views/welcome.blade.php ENDPATH**/ ?>