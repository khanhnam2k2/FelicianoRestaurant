<h1>Booking Confirmed</h1>

<p>Dear <?php echo e($reservation->name); ?>,</p>


<p>Your booking at My Restaurant has been confirmed 🎉🎉</p>

<p>Booking details:</p>

<ul>
    <li>Booking ID: <?php echo e($reservation->id); ?></li>
    <li>Date: <?php echo e($reservation->res_date); ?></li>
    <li>Number of guests: <?php echo e($reservation->guest_number); ?></li>
</ul>
<p>Our address: 🏡 182 Lê Duẩn - Đại học Vinh - Nghệ An </p>
<p>Thank you for choosing Our Feliciano Restaurant ❤️❤️❤️</p><?php /**PATH D:\Đại học Vinh\Đồ ăn năm 3\RestaurantApp\resources\views/emails/booking-confirmed.blade.php ENDPATH**/ ?>