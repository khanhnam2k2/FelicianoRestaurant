<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-12">
                <div class="bg-secondary rounded h-100 p-4">
                  <?php if(Auth::user()->utype =="ADM"): ?>
                   <a href="<?php echo e(route('admin.teams.create')); ?>" class="mb-4 btn btn-primary">New Chef</a>
                      
                  <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Job</th>
                                    <th scope="col">Description</th>
                                    <?php if(Auth::user()->utype == "ADM"): ?>
                                    <th scope="col">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($team->name); ?></td>
                                    <td>
                                        <img
                                            src="<?php echo e(Storage::url($team->image)); ?>"
                                            alt=""
                                            width="100%"
                                            height="300px"
                                            style="object-fit: cover"
                                        />
                                    </td>
                                    <td><?php echo e($team->job); ?></td>
                                    <td><?php echo e($team->description); ?></td>
                                    <?php if(Auth::user()->utype=="ADM"): ?>
                                    <td>
                                        <div class="d-flex">
                                        <a href="<?php echo e(route('admin.teams.edit',$team->id)); ?>" class="btn btn-info me-2">Edit</a>
                                        <form class=""
                                            method="POST"
                                            action="<?php echo e(route('admin.teams.destroy',$team->id)); ?>"
                                            onsubmit="return confirm('Are you sure?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger" type="submit">Delete</button>
                                        </form>
                                    </div>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end"><?php echo e($teams->links()); ?></div>
                </div>
            </div>
        </div>

    </div>
  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
 <?php /**PATH C:\Users\HA  NAM\Downloads\RestaurantApp\resources\views/admin/teams/index.blade.php ENDPATH**/ ?>