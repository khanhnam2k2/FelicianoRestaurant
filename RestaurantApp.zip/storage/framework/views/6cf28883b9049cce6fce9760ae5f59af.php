<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Sale & Revenue Start -->
    <div class="container-fluid pt-4 px-4">
      <div class="row g-4">
          <div class="col-sm-6 col-xl-3">
              <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa-solid fa-utensils fa-3x text-primary"></i>
                  <div class="ms-2">
                    <a href="<?php echo e(route('admin.menus.index')); ?>" class="mb-2">Menus</a>
                      <h6 class="mb-0"><?php echo e(count($menus) > 0 ? "Have ".count($menus) : "No"); ?> dish</h6>
                  </div>
              </div>    
          </div>
          <div class="col-sm-6 col-xl-3">
              <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa-solid fa-user-group fa-3x text-primary"></i>
                  <div class="ms-2">
                    <a href="<?php echo e(route('admin.customers.index')); ?>" class="mb-2">Customers</a>
                      <h6 class="mb-0">Have <?php echo e($total_customers); ?> Account</h6>
                  </div>
              </div>
          </div>
          <div class="col-sm-6 col-xl-3">
              <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa-solid fa-bell fa-3x text-primary" >
                    </i>
                  <div class="ms-2">
                      <a href="<?php echo e(route('admin.reservation.index')); ?>" class="mb-2">Reservation Today </a>
                      <h6 class="mb-0"><?php echo e(count($reservations_today)>0 ? "Have ".count($reservations_today) : "No"); ?> Reservation  </h6>
                  </div>
              </div>
          </div>
          <div class="col-sm-6 col-xl-3">
              <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                  <i class="fa-solid fa-blog fa-3x text-primary"></i>
                  <div class="ms-2">
                    <a href="<?php echo e(route('admin.posts.index')); ?>" class="mb-2">Posts posted</a>
                      <h6 class="mb-0">Have <?php echo e(count($posts)); ?> post</h6>
                  </div>
              </div>
          </div>
      </div>
  </div>
  <!-- Sale & Revenue End -->


  <!-- Recent Sales Start -->
  <div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-md-6">
            <div class="bg-secondary text-center rounded p-4">
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <h5 class="mb-0 text-primary ">Table Reservation Pending🛎️🛎️🛎️ </h5>
                    <a href="<?php echo e(route('admin.reservation.index')); ?>">View All</a>
                </div>
                <?php if(count($reservations_pending) >0): ?>
                <div class="table-responsive">
                    <table class="table text-start align-middle table-bordered table-hover mb-0">
                        <thead>
                            <tr class="text-white">
                                <th scope="col">Date</th>
                                
                                <th scope="col">Customer</th>
                                
                                <th scope="col">Guest Number</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $reservations_pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($reservation->res_date); ?></td>
                              
                              <td><?php echo e($reservation->name); ?></td>
                              
                              <td><?php echo e($reservation->guest_number); ?></td>
                              <td><a class="btn btn-sm btn-primary" href="<?php echo e(route('admin.reservation.show',$reservation->id)); ?>">Process</a></td>
                          </tr>
                              
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </tbody>
                    </table>
                </div>
                 <?php else: ?>
                  <h2>No pending table orders🥲</h2>   
                <?php endif; ?>
            </div>
        </div>
        <div class="col-sm-12 col-md-6">
            <div class="bg-secondary text-center rounded p-4">
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <h5 class="mb-0 text-primary ">Table Reservation Confirmed  </h5>
                    <a href="<?php echo e(route('admin.reservation.index')); ?>">View All</a>
                </div>
                <?php if(count($reservations_confirmed) >0): ?>
                <div class="table-responsive">
                    <table class="table text-start align-middle table-bordered table-hover mb-0">
                        <thead>
                            <tr class="text-white">
                                <th scope="col">Date</th>
                                
                                <th scope="col">Customer</th>
                                
                                <th scope="col">Guest Number</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $reservations_confirmed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($reservation->res_date); ?></td>
                              
                              <td><?php echo e($reservation->name); ?></td>
                              
                              <td><?php echo e($reservation->guest_number); ?></td>
                              <td><a class="btn btn-sm btn-primary" href="<?php echo e(route('admin.reservation.show',$reservation->id)); ?>">Process</a></td>
                          </tr>
                              
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </tbody>
                    </table>
                </div>
                 <?php else: ?>
                  <h2>No confirmed table orders </h2>   
                <?php endif; ?>
            </div>
        </div>
    </div>
   
  </div>
  <!-- Recent Sales End -->


  <!-- Widgets Start -->
  <div class="container-fluid pt-4 px-4">
      <div class="row g-4">
          
          <div class="col-sm-12 col-md-6 ">
              <div class="h-100 bg-secondary rounded p-4">
                  <div class="d-flex align-items-center justify-content-between mb-4">
                      <h6 class="mb-0">Calender</h6>
                      <a href="">Show All</a>
                  </div>
                  <div id="calender"></div>
              </div>
          </div>
          <div class="col-sm-12 col-md-6">
              <div class="h-100 bg-secondary rounded p-4">
                  <div class="d-flex align-items-center justify-content-between mb-4">
                      <h6 class="mb-0 text-primary">Recent posts <span class="text-info">(7days)</span></h6>
                      <a href="<?php echo e(route('admin.posts.index')); ?>">View All</a>
                  </div>
                  <?php if(count($rencent_posts)>0): ?>
                  <div class="table-responsive">
                    <table class="table text-start align-middle table-bordered table-hover mb-0">
                        <thead>
                            <tr class="text-white">
                                <th scope="col">Title</th>
                                <th scope="col">Image</th>
                                <th scope="col">Created at</th>
                                <th scope="col">Author</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rencent_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($post->title); ?></td>
                                <td><img src="<?php echo e(Storage::url($post->image)); ?>" width="100px" alt=""></td>
                                <td><?php echo e($post->created_at->format('d-m-Y')); ?></td>
                                <td><?php echo e($post->user->name == Auth::user()->name ? "You" : $post->user->name); ?></td>
                                <td><a class="btn btn-sm btn-primary" href="<?php echo e(route('admin.posts.show',$post->id)); ?>">Detail</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                           
                        </tbody>
                    </table>
                </div>
                  <?php else: ?>
                      <h2 class="text-primary text-center">No Post</h2>
                  <?php endif; ?>
                  
                  
                  
              </div>
          </div>
      </div>
  </div>
  <!-- Widgets End -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\Đại học Vinh\Đồ ăn năm 3\RestaurantApp\resources\views/admin/index.blade.php ENDPATH**/ ?>