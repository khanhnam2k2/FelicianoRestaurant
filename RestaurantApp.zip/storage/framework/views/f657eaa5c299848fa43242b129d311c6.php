<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['team']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['team']); ?>
<?php foreach (array_filter((['team']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="col-md-6 col-lg-3 ftco-animate">
    <div class="staff">
        <div class="img" style="background-image: url(<?php echo e(Storage::url($team->image)); ?>);"></div>
        <div class="text pt-4">
            <h3><?php echo e($team->name); ?></h3>
            <span class="position mb-2"><?php echo e($team->job); ?></span>
            <div class="faded">
                <ul class="ftco-social d-flex">
    <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
    <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
    <li class="ftco-animate"><a href="#"><span class="icon-google-plus"></span></a></li>
    <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
  </ul>
</div>
        </div>
    </div>
</div><?php /**PATH C:\Users\HA  NAM\Downloads\RestaurantApp\resources\views/components/team-card.blade.php ENDPATH**/ ?>