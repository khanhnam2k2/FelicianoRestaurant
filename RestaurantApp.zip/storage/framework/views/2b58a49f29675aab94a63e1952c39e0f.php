<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <?php $__env->startSection('title', 'Menu - Feliciano Restaurant'); ?>

    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.hero-card','data' => ['namePage' => 'Menu','bg' => 'images/bg_2.jpg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('hero-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['namePage' => 'Menu','bg' => 'images/bg_2.jpg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <section class="ftco-section">
    	<div class="container">
        <div class="ftco-search">
          <form action="<?php echo e(route('menus.search')); ?>" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" name="query" class="form-control" placeholder="Search menu here">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                </div>
            </div>
        </form>
					<div class="row">
            <div class="col-md-12 nav-link-wrap">
	            <div class="nav nav-pills d-flex text-center" id="v-pills-tab" role="tablist" aria-orientation="vertical" style="justify-content: space-between">
                <a class="nav-link ftco-animate active"  data-toggle="pill" href="#all" role="tab" aria-controls="all" aria-selected="true">All</a>

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="nav-link ftco-animate"  data-toggle="pill" href="#<?php echo e($category->name); ?>" role="tab" aria-controls="<?php echo e($category->name); ?>" aria-selected="false"><?php echo e($category->name); ?></a>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	            </div>
	          </div>
	          <div class="col-md-12 tab-wrap">
	            <div class="tab-content" id="v-pills-tabContent">
                <div class="tab-pane fade show active" id="all" role="tabpanel" >
                  <div class="row no-gutters d-flex align-items-stretch">
                      <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-md-12 col-lg-6 d-flex align-self-stretch">
                          <div class="menus d-sm-flex ftco-animate align-items-stretch mt-4 mr-4">
                        <div class="menu-img img  " style="background-image: url(<?php echo e(Storage::url($menu->image)); ?>);"></div>
                        <div class="text d-flex align-items-center">
                                          <div>
                                <div class="d-flex">
                                  <div class="one-half">
                                    <h3><?php echo e($menu->name); ?></h3>
                                  </div>
                                  <div class="one-forth">
                                    <span class="price">$<?php echo e($menu->price); ?></span>
                                  </div>
                                </div>
                                <p class="mb-2 text-sm">
                                  Categories: 
                                  <?php $__currentLoopData = $menu->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <span class=""><?php echo e($category->name); ?>,</span>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </p>
                                <p><a href="<?php echo e(route('menus.show',$menu->id)); ?>" class="btn btn-primary">See details</a></p>
                            </div>
                        </div>
                      </div>
                      </div>
                          
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </div>
              </div>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane fade" id="<?php echo e($category->name); ?>" role="tabpanel" >
                        <div class="row no-gutters d-flex align-items-stretch">
                            <?php $__currentLoopData = $category->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-12 col-lg-6 d-flex align-self-stretch">
                                <div class="menus d-sm-flex ftco-animate align-items-stretch mt-4 mr-4">
                              <div class="menu-img img " style="background-image: url(<?php echo e(Storage::url($menu->image)); ?>);"></div>
                              <div class="text d-flex align-items-center">
                                                <div>
                                      <div class="d-flex">
                                        <div class="one-half">
                                          <h3><?php echo e($menu->name); ?></h3>
                                        </div>
                                        <div class="one-forth">
                                          <span class="price">$<?php echo e($menu->price); ?></span>
                                        </div>
                                      </div>
                                      <p class="mb-2 text-sm">
                                        Categories: 
                                        <?php $__currentLoopData = $menu->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class=""><?php echo e($category->name); ?>,</span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </p>
                                      <p><a href="<?php echo e(route('menus.show',$menu->id)); ?>" class="btn btn-primary">See details</a></p>
                                  </div>
                              </div>
                            </div>
                            </div>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                              </div>
                    </div>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	          
	            </div>
	          </div>
	        </div>
        </div>
    	</div>
    </section>  

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH D:\Đại học Vinh\Đồ ăn năm 3\RestaurantApp\resources\views/menus/index.blade.php ENDPATH**/ ?>