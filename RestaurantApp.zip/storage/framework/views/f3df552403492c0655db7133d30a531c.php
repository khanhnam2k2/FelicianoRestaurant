<p>Dear Admin, Hà Nam</p>

<p>A new table booking has been made by a customer:</p>

<ul>
    <li>Customer name: <?php echo e($reservation->name); ?></li>
    <li>Phone number: <?php echo e($reservation->tel_number); ?></li>
    <li>Email: <?php echo e($reservation->email); ?></li>
    <li>Date: <?php echo e($reservation->res_date); ?></li>
    <li>Number of guest: <?php echo e($reservation->guest_number); ?></li>
</ul>
<p>Please confirm your table reservation as soon as possible 😊😊😊</p>
<p>Thank you ❤️❤️❤️</p><?php /**PATH D:\Đại học Vinh\Đồ ăn năm 3\RestaurantApp\resources\views/emails/booking-notification.blade.php ENDPATH**/ ?>